## Template website undangan pernikahan sederhana

##### Demo: https://dewanakl.github.io/undangan/?to=Teman+teman+semua

##### Deployment API Vercel: [https://dikit.my.id/DeploymentApiVercel](https://dikit.my.id/DeploymentApiVercel)
##### Deployment API Hosting: [https://dikit.my.id/DeploymentApiHosting](https://dikit.my.id/DeploymentApiHosting)

### Tech stack
- Bootstrap 5.3.0
- AOS 2.3.4
- Fontawsome 6.4.0
- Google Fonts
- Vanilla JS

### Terima kasih banyak teman teman
